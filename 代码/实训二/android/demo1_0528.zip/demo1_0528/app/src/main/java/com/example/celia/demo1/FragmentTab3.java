package com.example.celia.demo1;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.celia.demo1.adapter.ZiXunTalkAdapter;
import com.example.celia.demo1.adapter.ZixunAdapter1;
import com.example.celia.demo1.bean.Article;
import com.example.celia.demo1.bean.GoodsBean;
import com.example.celia.demo1.bean.Writer;
import com.example.celia.demo1.bean.UserBean;
import com.example.celia.demo1.zixun.TaoWebActivity;
import com.example.celia.demo1.zixun.ZiXun2;
import com.example.celia.demo1.zixun.ZiXun2Experience;
import com.example.celia.demo1.zixun.ZiXun2Ziliao;
import com.example.celia.demo1.zixun.ZiXun3;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class FragmentTab3 extends Fragment {
    private ListView newsListView;
    private GridView talkGridView;
    private List<Article> newsList;
    private List<Article> talkList;
    private List<GoodsBean> goodsList = new ArrayList<>();
    private ZixunAdapter1 adapter;
    private TextView gengduo;
    private ZiXunTalkAdapter adapter2;
    private VideoView videoView;
    private List<Article> experienceList;
    private ListView expericenceListView;

    /*
     * 资讯——一级页面
     *
     * */
    //创建View时调用
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_page3,container,false);
        //View view = inflater.inflate(R.layout.fragment_page3,container,false);//根据布局文件产生布局控件
        //false 不放到第二个参数中，true 放到第二个参数中
        super.onCreate(savedInstanceState);
        //视频
        videoView=view.findViewById(R.id.vVideo);
        File videoFile=new File(getContext().getFilesDir()+"/shipin.mp4");
        if(videoFile.exists()){
            videoView.setVideoPath(videoFile.getAbsolutePath());
        }
        //3.播放视频
        if(!videoView.isPlaying()){
            videoView.start();
            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                    mp.setLooping(true);
                }
            });
        }

        //专栏圆角效果
        TextView text1=view.findViewById(R.id.tv_zhuanlan);
        text1.setBackgroundResource(R.drawable.corner_view);
        gengduo=view.findViewById(R.id.tv_gengduo);


        //显示高考新资讯
        newsListView= view.findViewById(R.id.zixun_index_news);
        initNewsData();
       //显示资料补给站内容
        talkGridView=view.findViewById(R.id.zixun_talk);
        initTalkData();
        //显示“经验分享”区
        expericenceListView=view.findViewById(R.id.zixun_index_jingyan);
        initExpericenceData();

        /*
         * 进入高考新资讯二级页面
         * */
        TextView tvgaokao=view.findViewById(R.id.tv_gaokao);
        tvgaokao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("test","点击了高考新资讯");
                Intent intent = new Intent();
                intent.setClass(getActivity().getApplicationContext(),ZiXun2.class);
                startActivity(intent);
            }
        });
        /*
         * 进入“经验分享区”的二级页面
         *
         * */
        TextView experience=view.findViewById(R.id.tv_gengduojingyan);
        experience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("test","点击了经验分享区");
                Intent intent = new Intent();
                intent.setClass(getActivity().getApplicationContext(),ZiXun2Experience.class);
                startActivity(intent);
            }
        });

        /*
         * 进入资料补给站的二级页面
         * */
        gengduo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("test——shop","点击了资料补给站");
                Intent intent=new Intent();
                intent.setClass(getActivity().getApplicationContext(), ZiXun2Ziliao.class);
                startActivity(intent);
            }
        });

        //当点击“高考新资讯”进入三级页面时
        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent();
                intent.setClass(getActivity().getApplicationContext(),ZiXun3.class);
                intent.putExtra("articleId",newsList.get(position).getArticleId());
                intent.putExtra("articleTitle",newsList.get(position).getArticleTitle());
                intent.putExtra("articleTime",newsList.get(position).getArticleTime());
                intent.putExtra("writer",newsList.get(position).getWriter());
                intent.putExtra("articleContent",newsList.get(position).getArticleContent());
                intent.putExtra("position",position);
                startActivity(intent);
            }
        });

        //当点击"经验百宝箱"进入三级页面时
        expericenceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent();
                intent.setClass(getActivity().getApplicationContext(),ZiXun3.class);
                intent.putExtra("articleId",experienceList.get(position).getArticleId());
                intent.putExtra("articleTitle",experienceList.get(position).getArticleTitle());
                intent.putExtra("articleTime",experienceList.get(position).getArticleTime());
                intent.putExtra("user",experienceList.get(position).getUser());
                intent.putExtra("articleContent",experienceList.get(position).getArticleContent());
                intent.putExtra("position",position);
                startActivity(intent);
            }
        });
        //跳转到淘宝
        talkGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tbPath=goodsList.get(position).getGoods_link();
//                Intent intent = new Intent();
//                intent.setAction("Android.intent.action.VIEW");
//                Uri uri = Uri.parse(tbPath); // 商品地址
//                intent.setData(uri);
//                intent.setClassName("com.taobao.taobao", "com.taobao.tao.detail.activity.DetailActivity");
//                startActivity(intent);

                if (isPkgInstalled(getContext(), "com.taobao.taobao")) {
                    gotoShop(getActivity(), tbPath);
//                }else if (isPkgInstalled(this, "com.tmall.wireless")) {
//                    gotoShop(this, tbPath);
                } else {
                    Toast.makeText(getContext(),"您还没有安装淘宝客户端！", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getContext(),TaoWebActivity.class);
                    intent.putExtra("url","https://item.taobao.com/item.htm?spm=a1z0d.6639537.1997196601.14.45d07484uw9hPZ&id=565080000925");
                    startActivity(intent);
                }
            }
        });



        return view;
    }

    //创建显示“经验分享区”中的数据
    private void initExpericenceData() {

        GetIndexExperienceListAsyncTask experienceListAsyncTask=new
                GetIndexExperienceListAsyncTask(getActivity().getApplicationContext(),expericenceListView);
        experienceListAsyncTask.execute();
    }

    //创建显示“经验分享区”的异步类
    class GetIndexExperienceListAsyncTask extends AsyncTask<String,Void,List<Article>> {
        private Context context;
        private ListView listView;
        public GetIndexExperienceListAsyncTask(Context ziXun, ListView listView1) {
            context=ziXun;
            listView=listView1;
        }

        @Override
        protected List<Article> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"ZiXunServlet?remark=getIndexExperienceList";
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("test", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                experienceList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    Article article = new Article();
                    article.setArticleId(object1.getInt("articleId"));
                    article.setArticleTitle(object1.getString("articleTitle"));
                    article.setArticleContent(object1.getString("articleContent"));
                    article.setArticleTime(object1.getString("articleTime"));
                    article.setArticleImg(object1.getString("articleImg"));
                    String userStr=object1.get("articleUser").toString();
                    UserBean userBean=new Gson().fromJson(userStr,UserBean.class);
                    /**/
                    article.setUser(userBean);
                    experienceList.add(article);
                }
                Log.e("test", experienceList.toString());
                return experienceList;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Article> articles) {
            Log.e("test","已经进行到异步类的显示阶段");
            adapter=new ZixunAdapter1(context, R.layout.zixun_index_jingyan,articles);
            expericenceListView.setAdapter(adapter);
        }
    }

    //创建显示高考新资讯的异步类
    class GetIndexNewsListAsyncTask extends AsyncTask<String,Void,List<Article>> {
        private Context context;
        private ListView listView;

        public GetIndexNewsListAsyncTask(Context ziXun, ListView listView1) {
            context=ziXun;
            listView=listView1;
        }

        @Override
        protected List<Article> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"ZiXunServlet?remark=getIndexNewsList";
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("test", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                newsList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    Article article = new Article();
                    article.setArticleId(object1.getInt("articleId"));
                    article.setArticleTitle(object1.getString("articleTitle"));
                    article.setArticleContent(object1.getString("articleContent"));
                    article.setArticleTime(object1.getString("articleTime"));
                    article.setArticleImg(object1.getString("articleImg"));
                    String writerStr=object1.get("articleWriter").toString();
                    Writer writer=new Gson().fromJson(writerStr,Writer.class);
                    /**/
                    article.setWriter(writer);
                    newsList.add(article);
                }
                Log.e("test", newsList.toString());
                return newsList;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(List<Article> result){
            Log.e("test","已经进行到异步类的显示阶段");
            adapter=new ZixunAdapter1(context, R.layout.zixun_index_news,result);
            newsListView.setAdapter(adapter);
        }
    }
    //创建高考新资讯内容
    private void initNewsData() {
        GetIndexNewsListAsyncTask asyncTask1=new GetIndexNewsListAsyncTask(getActivity().getApplicationContext(),newsListView);
        asyncTask1.execute();
    }

    //创建资料补给站的异步类
    class GetGoodsListAsyncTask extends AsyncTask<String,Void,List<GoodsBean>>{
        private Context context1;
        private GridView gridView;

        public GetGoodsListAsyncTask(Context context1, GridView gridView) {
            this.context1 = context1;
            this.gridView = gridView;
        }

        @Override
        protected List<GoodsBean> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"GoodsServlet?remark=getIndexGoodsList";
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");///解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("testtest", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                Log.e("testarray",array.toString());
                goodsList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    GoodsBean goods = new GoodsBean();
                    goods.setGoods_id(object1.getInt("goodsId"));
                    goods.setGoods_name(object1.getString("goodsName"));
//                    goods.setGoods_price(object1.getInt("goodsPrice"));
                    goods.setGoods_img(object1.getString("goodsImg"));
                    goods.setGoods_link(object1.getString("goodsLink"));
                    goodsList.add(goods);
                }
                Log.e("test", goodsList.toString());
                return goodsList;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(List<GoodsBean> result){
            Log.e("test","已经进行到异步类的显示阶段");
            adapter2=new ZiXunTalkAdapter(context1, R.layout.zixun_index_talk,result);
            gridView.setAdapter(adapter2);
        }
    }



    //创建资料补给站内容
    private void initTalkData() {
        GetGoodsListAsyncTask asyncTask2=new GetGoodsListAsyncTask(getActivity().getApplicationContext(),talkGridView);
        asyncTask2.execute();
    }

    //判断是否安装淘宝App
    //@return true:已安装；false：未安装
    public static boolean isPkgInstalled(Context context, String pkgName) {
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(pkgName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            packageInfo = null;
            e.printStackTrace();
        }
        return packageInfo != null;
    }

    //跳转商铺
    public static void gotoShop(Activity activity, String url) {
        try {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setData(Uri.parse(url));
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //当view创建完成
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
