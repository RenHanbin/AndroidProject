package com.example.celia.demo1.zixun;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.GoodsBean;
import com.example.celia.demo1.showImgAsyncTask.ShowImgAsyncTask;

import java.util.ArrayList;
import java.util.List;

public class ZiXunGoodsAdapter extends BaseAdapter {
    private Context context;
    private int itemLayout;
    private List<GoodsBean> goodsList = new ArrayList<GoodsBean>();

    public ZiXunGoodsAdapter(Context context, int itemLayout, List<GoodsBean> goodsList) {
        this.context = context;
        this.itemLayout = itemLayout;
        this.goodsList = goodsList;
    }

    @Override
    public int getCount() {
        return goodsList.size();
    }

    @Override
    public Object getItem(int position) {
        return goodsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater=LayoutInflater.from(context);
            convertView=inflater.inflate(itemLayout,null);
        }
        TextView goodsName=convertView.findViewById(R.id.tv_goods_name);
        ImageView goodsImg=convertView.findViewById(R.id.iv_goods_img);

        GoodsBean goods=goodsList.get(position);
        goodsName.setText(goods.getGoods_name());

        //异步类显示图片
        String murl1=goods.getGoods_img();
        Glide.with(context).load(murl1).into(goodsImg);
//        String murl1=goods.getGoods_img();
//        ShowImgAsyncTask showImg=new ShowImgAsyncTask(murl1,goodsImg);
//        showImg.execute();
        return convertView;
    }
}
