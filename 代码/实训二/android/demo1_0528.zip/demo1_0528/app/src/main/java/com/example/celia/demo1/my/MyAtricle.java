package com.example.celia.demo1.my;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;
import com.example.celia.demo1.adapter.MyArticleAdapter;
import com.example.celia.demo1.adapter.ZixunExperienceAdapter;
import com.example.celia.demo1.bean.Article;
import com.example.celia.demo1.bean.UserBean;
import com.example.celia.demo1.zixun.TabHostActivity;
import com.example.celia.demo1.zixun.ZiXun2Experience;
import com.example.celia.demo1.zixun.ZiXun3;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyAtricle extends AppCompatActivity{
    private ListView listArticle;
    private List<Article> myArticles;
    private MyArticleAdapter myArticleAdapter;
    private LinearLayout linearLayout;
    private int userId;

    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.my_article);
        final ContextData data= (ContextData) getApplication();
        userId=data.getUserId();
        Log.e("userId",userId+"");
        listArticle= findViewById(R.id.lv_my_article);
        linearLayout=findViewById(R.id.ll_article);
        initData();

        //点击写文章
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(MyAtricle.this,ThreeMyArticle.class);
                startActivity(intent);
            }
        });


        //当点击进入三级页面时
        listArticle.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent();
                intent.setClass(MyAtricle.this,ZiXun3.class);
                intent.putExtra("articleId",myArticles.get(position).getArticleId());
                intent.putExtra("articleTitle",myArticles.get(position).getArticleTitle());
                intent.putExtra("articleTime",myArticles.get(position).getArticleTime());
                intent.putExtra("user",myArticles.get(position).getUser());
                intent.putExtra("articleContent",myArticles.get(position).getArticleContent());
                intent.putExtra("position",position);
                startActivity(intent);
            }
        });

        //点击“<”，返回上一级界面我的my
        ImageView Ireturn=findViewById(R.id.iv_return);
        Ireturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(MyAtricle.this, TabHostActivity.class);
                intent.putExtra("id", 3);
                startActivityForResult(intent,3);
            }
        });
    }

    //创建获取所有用户写过的文章的异步类
    class GetExperienceListAsyncTask extends AsyncTask<String,Void,List<Article>> {
        private Context context;
        private ListView mlistView;

        public GetExperienceListAsyncTask(Context ziXun2, ListView gridView1) {
            context=ziXun2;
            mlistView=gridView1;
        }

        @Override
        protected List<Article> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"MyArticle?remark=getAllArticle&userId="+userId;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                myArticles=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    Article article = new Article();
                    article.setArticleId(object1.getInt("articleId"));
                    article.setArticleTitle(object1.getString("articleTitle"));
                    article.setArticleContent(object1.getString("articleContent"));
                    article.setArticleTime(object1.getString("articleTime"));
                    article.setArticleImg(object1.getString("articleImg"));
                    String userStr=object1.get("articleUser").toString();
                    UserBean userBean=new Gson().fromJson(userStr,UserBean.class);
                    /**/
                    article.setUser(userBean);
                    myArticles.add(article);
                }
                return myArticles;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(List<Article> result){
            Log.e("test","已经进行到异步类的显示阶段");
            myArticleAdapter=new MyArticleAdapter(context,result,R.layout.my_article_list);
            mlistView.setAdapter(myArticleAdapter);
        }
    }
    //创建资讯2级页面“经验分享区”的数据
    private void initData() {

        GetExperienceListAsyncTask asyncTask=new GetExperienceListAsyncTask
                (MyAtricle.this,listArticle);
        asyncTask.execute();
    }


}
