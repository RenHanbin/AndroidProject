package com.example.celia.demo1.zixun;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Comm;
import com.example.celia.demo1.bean.UserBean;
import com.example.celia.demo1.bean.Writer;
import com.example.celia.demo1.my.MyTopic;
import com.example.celia.demo1.shequ.CommWrite;
import com.example.celia.demo1.showImgAsyncTask.ShowImgAsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ZiXun3 extends AppCompatActivity {
    private int articleId;
    private Boolean flag=false;
    private ImageView collection;
    private TextView text;
    private int userId;
    private String page;//上一级跳转页面的标志位
    private ListView listView;
    private List<Comm> commList;
    private CustomAdapter adapter;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zixun3);
        final ContextData data= (ContextData) getApplication();
        userId=data.getUserId();
        Log.e("userId",userId+"");
        Intent intent=getIntent();
        articleId=intent.getIntExtra("articleId",0);
        //TextView articleTitle=findViewById(R.id.tv_articleTitle);
        TextView articleTitle1=findViewById(R.id.tv_article_title);
        TextView articleTime=findViewById(R.id.tv_articleTime);
        TextView articleContent=findViewById(R.id.tv_articleContent);
        ImageView writerImg=findViewById(R.id.writerImg);
        TextView writerName=findViewById(R.id.tv_writerName);
        text=findViewById(R.id.tv_collection_text);
        page=intent.getStringExtra("page");
        //articleTitle.setText(intent.getStringExtra("articleTitle"));
        articleTitle1.setText(intent.getStringExtra("articleTitle"));
        articleContent.setText(intent.getStringExtra("articleContent"));
        articleTime.setText(intent.getStringExtra("articleTime"));
//        String url="";
        if(intent.getSerializableExtra("writer")==null){
            Log.e("zixuntest","进入的是经验分享区");
            UserBean userBean= (UserBean) intent.getSerializableExtra("user");
            writerName.setText(userBean.getUserName());
//            url=userBean.getUserImg();
            String strings = userBean.getUserImg();
            String s = strings.replace(" ", "+");
            Log.e("test",s);
            Bitmap bitmap = stringToBitmap(s);
            writerImg.setImageBitmap(bitmap);
        }else{
            Log.e("zixuntest","进入的是高考咨询区");
            Writer writer= (Writer) intent.getSerializableExtra("writer");
            writerName.setText(writer.getWriterName());
//            url=writer.getWriterImg();
            String strings = writer.getWriterImg();
            RequestOptions requestOptions=new RequestOptions().circleCrop();
            Glide.with(this).load(strings).apply(requestOptions).into(writerImg);
            /*String s = strings.replace(" ", "+");
            Log.e("test",s);
            Bitmap bitmap = stringToBitmap(s);
            writerImg.setImageBitmap(bitmap);*/
        }
//        RequestOptions requestOptions=new RequestOptions().circleCrop();
//        Glide.with(this).load(url).apply(requestOptions).into(writerImg);
        //点击返回按钮返回
        LinearLayout linearLayout=findViewById(R.id.ll_return1);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if("MyTopic".equals(page)){
                    Intent backIntent=new Intent();
                    backIntent.setClass(ZiXun3.this, MyTopic.class);
                    startActivity(backIntent);
                    finish();
                }else{
                    finish();
                }

            }
        });

        //判断是否收藏过
        IfCollectionedAsyncTask asyncTasked=new IfCollectionedAsyncTask();
        asyncTasked.execute();
        //收藏
        collection=findViewById(R.id.iv_collection);
        collection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag==false){
                    collection.setImageResource(R.drawable.dianzan2);
                    text.setText("已收藏");
                    flag=true;
                    //向数据库中加入收藏的文章
                    AddCollectionAsyncTask asyncTask=new AddCollectionAsyncTask(ZiXun3.this);
                    asyncTask.execute();
                }else{
                    collection.setImageResource(R.drawable.dianzan);
                    text.setText("添加收藏");
                    flag=false;
                    //取消收藏
                    DeleteCollectionAsyncTask deleteAsyncTask=new DeleteCollectionAsyncTask(ZiXun3.this);
                    deleteAsyncTask.execute();
                }
            }
        });

        //评论列表
        listView = findViewById(R.id.comm_listview);
        initData();
        //写评论
        LinearLayout writeComm=findViewById(R.id.write_comm);
        writeComm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent();
                intent1.setClass(ZiXun3.this,CommWrite.class);
                intent1.putExtra("articleId",articleId);
                intent1.putExtra("str","ZiXun3");
                startActivityForResult(intent1,1);
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2){
            articleId = data.getIntExtra("articleId",1);
            Comm comm=new Comm();
            comm.setUserId(userId);
            comm.setCommUserImg(data.getStringExtra("commUserImg"));
            comm.setCommUserName(data.getStringExtra("commUserName"));
            comm.setCommentTime(data.getStringExtra("commTime"));
            comm.setCommentContent(data.getStringExtra("commComtent"));
            commList.add(comm) ;
            adapter.notifyDataSetChanged();
        }
    }


    //判断是否收藏过的异步类
    private class IfCollectionedAsyncTask extends AsyncTask<String,Void,Boolean> {

        private String success;
        private String falseStr;
        private Boolean b=false;
        @Override
        protected Boolean doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                URL url=new URL(path+"CollectionArticleServlet?remark=ifExistCollectionArticle&articleId="+ articleId
                        +"&userId="+userId);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test",str);
                JSONObject object=new JSONObject(str);
                if(object.getString("success")!=null){
                    success=object.getString("success");
                    Log.e("test",success);
                    b=true;
                    return b;
                }else if(object.getString("false")!=null){
                    falseStr=object.getString("false");
                    Log.e("test",falseStr);
                    b=false;
                    return b;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //已经收藏过
                flag=true;
                collection.setImageResource(R.drawable.dianzan2);
                text.setText("已收藏");
            }else{
                //未收藏
                flag=false;

            }
        }
    }
    //添加收藏专业的异步类
    private class AddCollectionAsyncTask extends AsyncTask<String,Void,Boolean>{

        private String success;
        private String falseStr;
        private Boolean b=false;
        private Context mContext;
        protected AddCollectionAsyncTask(Context context){
            mContext=context;
        }
        @Override
        protected Boolean doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                URL url=new URL(path+"CollectionArticleServlet?remark=addArticleCollection&articleId="+ articleId
                        +"&userId="+userId);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test",str);
                JSONObject object=new JSONObject(str);
                if(object.getString("success")!=null){
                    success=object.getString("success");
                    Log.e("test",success);
                    b=true;
                    return b;
                }else if(object.getString("false")!=null){
                    falseStr=object.getString("false");
                    Log.e("test",falseStr);
                    b=false;
                    return b;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //收藏成功
                Toast.makeText(mContext,"收藏成功",Toast.LENGTH_SHORT).show();
            }else{
                //注册失败
                Toast.makeText(mContext,"收藏失败",Toast.LENGTH_LONG).show();
            }
        }
    }

    //取消收藏专业
    private class DeleteCollectionAsyncTask extends AsyncTask<String,Void,Boolean>{

        private String success;
        private String falseStr;
        private Boolean b=false;
        private Context mContext;

        protected DeleteCollectionAsyncTask(Context context){
            mContext=context;
        }
        @Override
        protected Boolean doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                URL url=new URL(path+"CollectionArticleServlet?remark=deleteArticleCollection&articleId="+ articleId
                        +"&userId="+userId);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test",str);
                JSONObject object=new JSONObject(str);
                if(object.getString("success")!=null){
                    success=object.getString("success");
                    Log.e("test",success);
                    b=true;
                    return b;
                }else if(object.getString("false")!=null){
                    falseStr=object.getString("false");
                    Log.e("test",falseStr);
                    b=false;
                    return b;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return false;
        }


        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //收藏成功
                Toast.makeText(mContext,"取消收藏成功",Toast.LENGTH_SHORT).show();
            }else{
                //注册失败
                Toast.makeText(mContext,"取消收藏失败",Toast.LENGTH_LONG).show();
            }
        }
    }

    public static Bitmap stringToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray = Base64.decode(string, Base64.NO_WRAP);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }
    //评论列表
    public class CustomAdapter extends BaseAdapter {

        private Context context;
        private int itemLayoutID;
        private List<Comm> commList;

        public CustomAdapter(Context context, int itemLayoutID, List<Comm> commList) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.commList = commList;
        }

        @Override
        public int getCount() {
            return commList.size();
        }

        @Override
        public Object getItem(int position) {
            return commList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                LayoutInflater inflater=LayoutInflater.from(context);
                convertView=inflater.inflate(itemLayoutID,null);
            }
            ImageView imageView=convertView.findViewById(R.id.comm_userImg);
            TextView commUserName=convertView.findViewById(R.id.tv_comm_name);
            TextView commTime=convertView.findViewById(R.id.tv_comm_time);
            TextView commContent=convertView.findViewById(R.id.tv_comm_content);

            Comm comm=commList.get(position);
            String imgUrl=comm.getCommUserImg();
            String s = imgUrl.replace(" ", "+");
            Log.e("test",s);
            Bitmap bitmap = stringToBitmap(s);
            imageView.setImageBitmap(bitmap);
            commUserName.setText(comm.getCommUserName());
            commTime.setText(comm.getCommentTime());
            commContent.setText(comm.getCommentContent());

            //加。。。
            return convertView;
        }
    }

    class GetCommListByArticleIdAsyncTask extends AsyncTask<String, Void, List<Comm>> {
        private Context mContext;
        private ListView mlistView;
        private int articleId;

        public GetCommListByArticleIdAsyncTask(Context mContext, ListView mlistView, int articleId) {
            this.mContext = mContext;
            this.mlistView = mlistView;
            this.articleId = articleId;
        }

        @Override
        protected List<Comm> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"CommentServlet?remark=selectCommListByArticleId&articleId="+articleId;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("1111", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                commList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    Comm comm=new Comm();
                    comm.setCommUserImg(object1.getString("commUserImg"));
                    comm.setCommUserName(object1.getString("commUserName"));
                    comm.setCommentTime(object1.getString("commTime"));
                    Log.i("lww",comm.getCommentTime());
                    comm.setCommentContent(object1.getString("commComtent"));
                    commList.add(comm);
                }
                return commList;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                Log.e("eeeee","chuocuo");
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Comm> comms) {
            adapter=new CustomAdapter(mContext,R.layout.comm_listview_item,comms);
            mlistView.setAdapter(adapter);
        }
    }
    private void initData() {
        GetCommListByArticleIdAsyncTask asyncTask=new GetCommListByArticleIdAsyncTask(ZiXun3.this,listView,articleId);
        asyncTask.execute();
    }

}
