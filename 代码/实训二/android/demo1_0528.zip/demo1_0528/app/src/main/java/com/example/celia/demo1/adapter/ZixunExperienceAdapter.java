package com.example.celia.demo1.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.ContactsContract;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Article;
import com.example.celia.demo1.showImgAsyncTask.ShowImgAsyncTask;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ZixunExperienceAdapter extends BaseAdapter {

    private Context context;
    private int itemLayout;
    private List<Article> experList = new ArrayList<Article>();
    private TextView articleName;
    private TextView articleTime ;
    private TextView userName;
    private ImageView imageView;

    public ZixunExperienceAdapter(Context context,int itemLayout,List<Article> articles){
        this.context=context;
        this.itemLayout=itemLayout;
        experList=articles;
    }
    @Override
    public int getCount() {
        return experList.size();
    }

    @Override
    public Object getItem(int position) {
        return experList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater=LayoutInflater.from(context);
            convertView=inflater.inflate(itemLayout,null);
        }
        articleName = convertView.findViewById(R.id.tv_article_title_jingyan);
        articleTime = convertView.findViewById(R.id.tv_articleTime_jingyan);
        userName=convertView.findViewById(R.id.tv_userName_jingyan);
        imageView=convertView.findViewById(R.id.iv_userImg_jingyan);
        //2. 填充数据
        Article article = experList.get(position);
        articleName.setText(article.getArticleTitle());
        articleTime.setText(article.getArticleTime());
        userName.setText(article.getUser().getUserName());

        String strings = article.getUser().getUserImg();
        String s = strings.replace(" ", "+");
        Bitmap bitmap = stringToBitmap(s);
        imageView.setImageBitmap(bitmap);
//        ShowImgAsyncTask showImg=new ShowImgAsyncTask(s,vh.imageView);
//        showImg.execute();
        Log.e("articleImage",article.getUser().getUserImg());
//        Glide.with(context).load(article.getUser().getUserImg()).into(vh.imageView);
        return convertView;
    }


    public static Bitmap stringToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray = Base64.decode(string, Base64.NO_WRAP);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }
}
