package com.example.celia.demo1.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Article;

import java.util.ArrayList;
import java.util.List;
import static com.example.celia.demo1.FragmentTab4.stringToBitmap;


public class ZixunExperienceAdapter extends BaseAdapter {

    private Context context;
    private List<Article> experList = new ArrayList<Article>();

    public ZixunExperienceAdapter(Context context,List<Article> articles){
        this.context=context;
        experList=articles;
    }
    @Override
    public int getCount() {
        return experList.size();
    }

    @Override
    public Object getItem(int position) {
        return experList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder vh = null;
        //1. 获取item子布局
        if(null == convertView){
            convertView = LayoutInflater.from(context).inflate(
                    R.layout.index2_jingyan_item_layout, null);
            vh = new ViewHolder();
            vh.articleName = convertView.findViewById(R.id.tv_article_title);
            vh.articleTime = convertView.findViewById(R.id.tv_articleTime);
            vh.userName=convertView.findViewById(R.id.tv_userName);
            vh.imageView=convertView.findViewById(R.id.iv_userImg);
            //缓存ViewHolder对象
            convertView.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }
        //2. 填充数据
        Article article = experList.get(position);
        vh.articleName.setText(article.getArticleTitle());
        vh.articleTime.setText(article.getArticleTime());
        vh.userName.setText(article.getUser().getUserName());
        String strings = article.getUser().getUserImg();
        String s = strings.replace(" ", "+");
        Log.e("test",s);
        Bitmap bitmap = stringToBitmap(s);
        vh.imageView.setImageBitmap(bitmap);
//        Glide.with(context).load(article.getUser().getUserImg()).into(vh.imageView);
        return convertView;
    }

    class ViewHolder{
        private TextView articleName;
        private TextView articleTime;
        private TextView userName;
        private ImageView imageView;
    }
}
