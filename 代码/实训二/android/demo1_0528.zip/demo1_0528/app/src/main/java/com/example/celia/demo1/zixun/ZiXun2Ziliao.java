package com.example.celia.demo1.zixun;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.GoodsBean;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.mob.MobSDK.getContext;

public class ZiXun2Ziliao extends AppCompatActivity {

    private List<GoodsBean> goodsList;
    private GridView gridView;
    private ZiXunGoodsAdapter adapter;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zixun2_talk);
        gridView=findViewById(R.id.zixun2_goods_list);
        initData();
        //当点击进入三级页面时
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //打开淘宝 注意：商品的url一定要写对
//                String tbPath="https://item.taobao.com/item.htm?spm=a1z0d.6639537.1997196601.14.45d07484uw9hPZ&id=565080000925";
                String tbPath=goodsList.get(position).getGoods_link();
//                Intent intent = new Intent();
//                intent.setAction("Android.intent.action.VIEW");
//                Uri uri = Uri.parse(tbPath); // 商品地址
//                intent.setData(uri);
//                intent.setClassName("com.taobao.taobao", "com.taobao.tao.detail.activity.DetailActivity");
//                startActivity(intent);

                if (isPkgInstalled(getContext(), "com.taobao.taobao")) {
                    gotoShop(ZiXun2Ziliao.this, tbPath);
//                }else if (isPkgInstalled(this, "com.tmall.wireless")) {
//                    gotoShop(this, tbPath);
                } else {
                    Toast.makeText(getContext(),"您还没有安装淘宝客户端！", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getContext(),TaoWebActivity.class);
                    intent.putExtra("url","https://item.taobao.com/item.htm?spm=a1z0d.6639537.1997196601.14.45d07484uw9hPZ&id=565080000925");
                    startActivity(intent);
                }
            }
        });
        //点击返回按钮返回
        LinearLayout linearLayout=findViewById(R.id.ll_return1);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    //创建异步类
    class GetTalkListAsyncTask extends AsyncTask<String,Void,List<GoodsBean>>{
        private Context context;
        private GridView gridView;

        public GetTalkListAsyncTask(Context ziXun2, GridView gridView1) {
            context=ziXun2;
            gridView=gridView1;
        }

        @Override
        protected List<GoodsBean> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"GoodsServlet?remark=getGoodsList";
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("test", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                goodsList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    GoodsBean goods = new GoodsBean();
                    goods.setGoods_id(object1.getInt("goodsId"));
                    goods.setGoods_name(object1.getString("goodsName"));
                    goods.setGoods_link(object1.getString("goodsLink"));
                    goods.setGoods_img(object1.getString("goodsImg"));
                    Log.i("goods_img",object1.getString("goodsImg"));
                    /**/
                    goodsList.add(goods);
                }
                Log.e("testGoodsList", goodsList.toString());
                return goodsList;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(List<GoodsBean> result){
            Log.e("test","已经进行到异步类的显示阶段");
            adapter=new ZiXunGoodsAdapter(context, R.layout.zixun2_talk_item,result);
            gridView.setAdapter(adapter);
        }
    }

    //判断是否安装淘宝App
    //@return true:已安装；false：未安装
    public static boolean isPkgInstalled(Context context, String pkgName) {
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(pkgName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            packageInfo = null;
            e.printStackTrace();
        }
        return packageInfo != null;
    }

    //跳转商铺
    public static void gotoShop(Activity activity, String url) {
        try {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setData(Uri.parse(url));
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //创建填充数据
    private void initData() {
        GetTalkListAsyncTask asyncTask1=new GetTalkListAsyncTask(ZiXun2Ziliao.this,gridView);
        asyncTask1.execute();
    }
}
