package com.example.celia.demo1.shequ;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Comm;
import com.example.celia.demo1.zixun.ZiXun3;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class CommWrite extends AppCompatActivity {
    private TextView submit;
    private EditText commContent;
    private int answerId;
    private int userId;
    private String content;
    private int articleId;
    private String str;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.shequ_comm_write);
        submit=findViewById(R.id.tv_comm_submit);
        commContent=findViewById(R.id.commContent);
        final ContextData data= (ContextData) getApplication();
        userId=data.getUserId();
        Log.e("userId",userId+"");
        Intent intent = getIntent();
        answerId=intent.getIntExtra("answerId",0);
        articleId=intent.getIntExtra("articleId",0);
        str=intent.getStringExtra("str");

        //返回上一级界面
        ImageView error=findViewById(R.id.comm_error);
        error.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //提交
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content=commContent.getText().toString();
                SubmitCommAsyncTask asyncTask=new SubmitCommAsyncTask(CommWrite.this);
                asyncTask.execute();
            }
        });

    }
    private class SubmitCommAsyncTask extends AsyncTask<String,Void,Boolean> {

        private String success;
        private String falseStr;
        private Boolean b = false;
        private Context mContext;

        public SubmitCommAsyncTask(Context mContext) {
            this.mContext = mContext;
        }

        @Override
        protected Boolean doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                URL url=null;
                if ("QuestionAnswerDetail".equals(str)){
                    url=new URL(path+"CommentServlet?remark=addComm&answerId="+ answerId
                            +"&userId="+userId+"&commContent="+content);
                }else if("ZiXun3".equals(str)){
                    url=new URL(path+"CommentServlet?remark=addCommByArticleId&articleId="+ articleId
                            +"&userId="+userId+"&commContent="+content);
                }

                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test",str);
                JSONObject object=new JSONObject(str);
                if(object.getString("success")!=null){
                    success=object.getString("success");
                    Log.e("test",success);
                    b=true;
                    return b;
                }else if(object.getString("false")!=null){
                    falseStr=object.getString("false");
                    Log.e("test",falseStr);
                    b=false;
                    return b;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //发布成功
                Toast.makeText(mContext,"发布成功",Toast.LENGTH_LONG).show();
                //发布成功之后跳转
                CommentAsyncTask task = new CommentAsyncTask(CommWrite.this);
                task.execute();
                //startActivity(intent);

            }else{
                //发布失败
                Toast.makeText(mContext,"发布失败",Toast.LENGTH_LONG).show();
            }
        }
    }
    //获取Comment
    private class CommentAsyncTask extends AsyncTask<String,Void,Comm> {
        private Context mContext;

        public CommentAsyncTask(Context mContext) {
            this.mContext = mContext;
        }

        @Override
        protected Comm doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                URL url=null;
                if ("QuestionAnswerDetail".equals(str)){
                    url=new URL(path+"CommentServlet?remark=selectComm&answerId="+ answerId
                            +"&userId="+userId+"&commContent="+content);
                }else if("ZiXun3".equals(str)){
                    url=new URL(path+"CommentServlet?remark=selectCommByArticleId&articleId="+ articleId
                            +"&userId="+userId+"&commContent="+content);
                }
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test",str);
                JSONObject object1 = new JSONObject(str);
                Comm comm=new Comm();
                comm.setCommUserImg(object1.getString("commUserImg"));
                comm.setCommUserName(object1.getString("commUserName"));
                comm.setCommentTime(object1.getString("commTime"));
                Log.i("lww",comm.getCommentTime());
                comm.setCommentContent(object1.getString("commComtent"));
                return comm;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Comm comm) {
            Intent intent=new Intent();
            if ("QuestionAnswerDetail".equals(str)){
                intent.setClass(mContext,QuestionAnswerDetail.class);
                intent.putExtra("answerId",answerId);
            }else if("ZiXun3".equals(str)){
                intent.setClass(mContext,ZiXun3.class);
                intent.putExtra("articleId",articleId);
            }
            intent.putExtra("userId",userId);
            intent.putExtra("commUserImg",comm.getCommUserImg());
            intent.putExtra("commUserName",comm.getCommUserName());
            intent.putExtra("commTime",comm.getCommentTime());
            intent.putExtra("commComtent",comm.getCommentContent());
            setResult(2,intent);
            finish();
        }
    }
}
