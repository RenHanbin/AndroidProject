package com.example.celia.demo1.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.GoodsBean;

import java.util.ArrayList;
import java.util.List;

public class ZiXunTalkAdapter extends BaseAdapter {
    private Context context;
    private int itemLayout;
    private List<GoodsBean> goodsList = new ArrayList<GoodsBean>();
    private TextView goodsName;
    private ImageView goodsImg;
    private ImageView taoImg;
    private TextView number;


    public ZiXunTalkAdapter(Context context,int itemLayout,List<GoodsBean> goodsList){
        this.context=context;
        this.goodsList=goodsList;
        this.itemLayout=itemLayout;
    }
    @Override
    public int getCount() {
        return goodsList.size();
    }

    @Override
    public Object getItem(int position) {
        return goodsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater=LayoutInflater.from(context);
            convertView=inflater.inflate(itemLayout,null);
        }
        goodsName=convertView.findViewById(R.id.zixun2_goods_text);
        goodsImg=convertView.findViewById(R.id.zixun2_goods_img);
        taoImg=convertView.findViewById(R.id.iv_taoImg);
        number=convertView.findViewById(R.id.number);

        GoodsBean good=goodsList.get(position);
        goodsName.setText(good.getGoods_name());
        goodsName.setEllipsize(TextUtils.TruncateAt.END);
        goodsName.setMaxWidth(290);
        goodsName.setSingleLine(true);
        //异步类显示图片
        String murl1=good.getGoods_img();
//        String taobaoUrl="imgup04.iefans.net/iefans/2019-02/23/11/15508930974574_1.png";
//        RequestOptions options=new RequestOptions().circleCrop();
        Glide.with(context).load(murl1).into(goodsImg);
//        Glide.with(context).load(taobaoUrl).apply(options).into(taoImg);
        number.setText(position+1+"");
        return convertView;
    }
}
