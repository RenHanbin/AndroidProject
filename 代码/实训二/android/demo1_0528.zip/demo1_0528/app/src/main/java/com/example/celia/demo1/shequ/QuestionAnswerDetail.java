package com.example.celia.demo1.shequ;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Comm;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class QuestionAnswerDetail extends AppCompatActivity {
    private TextView questionTitlex;
    private TextView answerContentx;
    private TextView answerUserNamex;
    private TextView answerTimex;
    private ImageView answerUserImgx;
    private ListView listView;
    private List<Comm> commList;
    private CustomAdapter adapter;
    private int answerId;
    private int userId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.question_answer_detail);
        questionTitlex = findViewById(R.id.tv_question_title);
        answerContentx = findViewById(R.id.tv_answer_content);
        answerContentx.setMovementMethod(ScrollingMovementMethod.getInstance());//滚轮
        answerUserNamex = findViewById(R.id.answer_userName);
        answerTimex = findViewById(R.id.tv_answer_time);
        answerUserImgx = findViewById(R.id.answer_userImg);
        final ContextData data= (ContextData) getApplication();
        userId=data.getUserId();
        Log.e("userId",userId+"");

        //回答具体显示
        Intent intent = getIntent();
        String answerContent = intent.getStringExtra("answerContent");
        String answerUserName = intent.getStringExtra("answerUserName");
        String answerUserImg = intent.getStringExtra("answerUserImg");
        String answerTime = intent.getStringExtra("answerTime");
        String questionTitle = intent.getStringExtra("questionTitle");
        answerId=intent.getIntExtra("answerId",0);
        questionTitlex.setText(questionTitle);
        answerContentx.setText(answerContent);
        answerUserNamex.setText(answerUserName);
        answerTimex.setText(answerTime);
        String s = answerUserImg.replace(" ", "+");
        Log.e("test", s);
        Bitmap bitmap = stringToBitmap(s);
        answerUserImgx.setImageBitmap(bitmap);
        //评论列表
        listView = findViewById(R.id.comm_listview);
        initData();
        //写评论
        LinearLayout writeComm=findViewById(R.id.write_comm);
        writeComm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent();
                intent1.setClass(QuestionAnswerDetail.this,CommWrite.class);
                intent1.putExtra("answerId",answerId);
                intent1.putExtra("str","QuestionAnswerDetail");
                startActivityForResult(intent1,1);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2){
            answerId = data.getIntExtra("answerId",1);
            Comm comm=new Comm();
            comm.setUserId(userId);
            comm.setCommUserImg(data.getStringExtra("commUserImg"));
            comm.setCommUserName(data.getStringExtra("commUserName"));
            comm.setCommentTime(data.getStringExtra("commTime"));
            comm.setCommentContent(data.getStringExtra("commComtent"));
            commList.add(comm);
            adapter.notifyDataSetChanged();
        }
    }
    public static Bitmap stringToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray = Base64.decode(string, Base64.NO_WRAP);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }
    //评论列表
    public class CustomAdapter extends BaseAdapter {

        private Context context;
        private int itemLayoutID;
        private List<Comm> commList;

        public CustomAdapter(Context context, int itemLayoutID, List<Comm> commList) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.commList = commList;
        }

        @Override
        public int getCount() {
            return commList.size();
        }

        @Override
        public Object getItem(int position) {
            return commList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                LayoutInflater inflater=LayoutInflater.from(context);
                convertView=inflater.inflate(itemLayoutID,null);
            }
            ImageView imageView=convertView.findViewById(R.id.comm_userImg);
            TextView commUserName=convertView.findViewById(R.id.tv_comm_name);
            TextView commTime=convertView.findViewById(R.id.tv_comm_time);
            TextView commContent=convertView.findViewById(R.id.tv_comm_content);

            Comm comm=commList.get(position);
            String imgUrl=comm.getCommUserImg();
            String s = imgUrl.replace(" ", "+");
            Log.e("test",s);
            Bitmap bitmap = stringToBitmap(s);
            imageView.setImageBitmap(bitmap);
            commUserName.setText(comm.getCommUserName());
            commTime.setText(comm.getCommentTime());
            commContent.setText(comm.getCommentContent());

            //加。。。
            return convertView;
        }
    }
    class GetCommListAsyncTask extends AsyncTask<String, Void, List<Comm>> {
        private Context mContext;
        private ListView mlistView;
        private int answerId;

        public GetCommListAsyncTask(Context mContext, ListView mlistView, int answerId) {
            this.mContext = mContext;
            this.mlistView = mlistView;
            this.answerId = answerId;
        }

        @Override
        protected List<Comm> doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);
            String urlStr = path+"CommentServlet?remark=selectCommList&answerId="+answerId;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("1111", str);
                //解析jsonarray
                JSONArray array = new JSONArray(str);
                commList=new ArrayList<>();
                for (int i = 0; i < array.length(); ++i) {
                    JSONObject object1 = array.getJSONObject(i);
                    Comm comm=new Comm();
                    comm.setCommUserImg(object1.getString("commUserImg"));
                    comm.setCommUserName(object1.getString("commUserName"));
                    comm.setCommentTime(object1.getString("commTime"));
                    Log.i("lww",comm.getCommentTime());
                    comm.setCommentContent(object1.getString("commComtent"));
                    commList.add(comm);
                }
                return commList;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                Log.e("eeeee","chuocuo");
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Comm> comms) {
            adapter=new CustomAdapter(mContext,R.layout.comm_listview_item,comms);
            mlistView.setAdapter(adapter);
        }
    }
    private void initData() {
        Log.i("lww","answerId:"+answerId);
        GetCommListAsyncTask asyncTask=new GetCommListAsyncTask(QuestionAnswerDetail.this,listView,answerId);
        asyncTask.execute();
    }
}
