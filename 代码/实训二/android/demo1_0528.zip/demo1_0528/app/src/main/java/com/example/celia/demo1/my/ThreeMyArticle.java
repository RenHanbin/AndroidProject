package com.example.celia.demo1.my;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ThreeMyArticle extends AppCompatActivity {
    private String articleTitle;
    private String articleContent;
    private int userId;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.my_three_article);
        //返回我的二级界面
        ImageView error=findViewById(R.id.error);
        error.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ThreeMyArticle.this,MyAtricle.class);
                startActivity(intent);
            }
        });
        final ContextData data= (ContextData) getApplication();
        userId=data.getUserId();
        Log.e("userId=",userId+"");
        //发布文章
        TextView fabuArticle=findViewById(R.id.fabu_article);
        fabuArticle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etarticleTitle=findViewById(R.id.article_title);
                EditText etarticleContent=findViewById(R.id.article_content);
                articleTitle= String.valueOf(etarticleTitle.getText());
                Log.e("test",articleTitle);
                articleContent= String.valueOf(etarticleContent.getText());
                Log.e("test",articleContent);
                AddArticleAsyncTask addQuestionAsyncTask=new AddArticleAsyncTask(ThreeMyArticle.this);
                addQuestionAsyncTask.execute();
            }
        });
    }

    private class AddArticleAsyncTask extends AsyncTask<String,Void,Boolean> {

        private Context mContext;
        protected AddArticleAsyncTask(Context context){
            mContext=context;
        }
        @Override
        protected Boolean doInBackground(String... strings) {
            String path=getResources().getString(R.string.url_path);

            String urlStr=path+"MyArticle?remark=addArticle&title="+articleTitle+"&content="+articleContent+"&userId="+userId;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType", "utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);//转换流
                BufferedReader reader = new BufferedReader(inputStreamReader);//字符流
                String str = reader.readLine();
                Log.e("test", str);
                JSONObject object1 = new JSONObject(str);
                if(object1.getString("success")!=null){
                    return true;
                }else{
                    return false;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //收藏成功
                Toast.makeText(mContext,"添加成功",Toast.LENGTH_LONG).show();
            }else{
                //注册失败
                Toast.makeText(mContext,"添加失败",Toast.LENGTH_LONG).show();
            }
        }
    }
}
