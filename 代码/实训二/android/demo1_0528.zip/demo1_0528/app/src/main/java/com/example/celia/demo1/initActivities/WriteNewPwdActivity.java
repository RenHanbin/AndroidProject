package com.example.celia.demo1.initActivities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.celia.demo1.ContextData;
import com.example.celia.demo1.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class WriteNewPwdActivity extends AppCompatActivity {
    private int userId;
    private String newPwd;
    private EditText etNewPwd;
    private Button btnNewPwd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.write_new_pwd);
        etNewPwd = findViewById(R.id.et_new_pwd);
        btnNewPwd = findViewById(R.id.btn_new_pwd);
        Intent intent = getIntent();
        userId = intent.getIntExtra("userId",userId);
        Log.i("11111111",userId+"");

        //新密码提交
        btnNewPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newPwd=etNewPwd.getText().toString();
                Log.e("test",newPwd);
                NewPasswordAsyncTask newPasswordAsyncTask=new NewPasswordAsyncTask(WriteNewPwdActivity.this);
                newPasswordAsyncTask.execute();
            }
        });


        //点击返回按钮返回
        LinearLayout linearLayout=findViewById(R.id.ll_new_pwd_return1);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    //新密码提交的异步类
    private class NewPasswordAsyncTask extends AsyncTask<String,Void,Boolean> {
        private Context mContext;
        private String success;
        private String falseStr;
        private Boolean b;

        protected NewPasswordAsyncTask(Context context){
            mContext=context;
        }
        @Override
        protected Boolean doInBackground(String... strings) {
            try {
                String path=getResources().getString(R.string.url_path);
                Log.e("2222222",userId+"");
                URL url=new URL(path+"FindPasswordServlet?remark=newPwd&userId="+
                        userId+"&userNewPwd="+newPwd);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("contentType","utf-8");//解决给服务器端传输的乱码问题
                InputStream inputStream=connection.getInputStream();
                //字节流转字符流
                InputStreamReader inputStreamReader=new InputStreamReader(inputStream);//转换流
                BufferedReader reader=new BufferedReader(inputStreamReader);//字符流
                String str=reader.readLine();
                Log.e("test1",str);
                JSONObject object=new JSONObject(str);
                if(object.getString("success")!=null){
                    success=object.getString("success");
                    Log.e("test11",success);
                    b=true;
                    return b;
                }else if(object.getString("false")!=null){
                    falseStr=object.getString("false");
                    Log.e("test11",falseStr);
                    b=false;
                    return b;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if(aBoolean){
                //更改密码成功
                Toast.makeText(mContext,"更改密码成功",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
            }else{
                //更改密码失败
                if(!"".equals(falseStr)){
                    Toast.makeText(mContext,"更改密码失败",Toast.LENGTH_LONG).show();
                }

            }

        }
    }
}
