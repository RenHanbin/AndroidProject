package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;


import bean.GoodsBean;
import dao.GoodsDao;

/**
 * Servlet implementation class GoodsServlet
 */
@WebServlet("/GoodsServlet")
public class GoodsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GoodsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String remark=request.getParameter("remark");
		System.out.println("GoodsServlet:remark="+remark);
		if("getGoodsList".equals(remark)) {
			GoodsDao goodsDao=new GoodsDao();
			List<GoodsBean> goodsList = null;
			try {
				goodsList = goodsDao.getAllGoods();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JSONArray jsonArray=new JSONArray();
			for(int i=0;i<goodsList.size();i++) {
				JSONObject object=new JSONObject();
				object.put("goodsId",goodsList.get(i).getGoods_id());
				object.put("goodsName",goodsList.get(i).getGoods_name());
				object.put("goodsImg",goodsList.get(i).getGoods_img());
//				object.put("goodsPrice",goodsList.get(i).getGoods_price());
				object.put("goodsLink",goodsList.get(i).getGoods_link());
				jsonArray.put(object);
			}
			System.out.println("GoodsServlet:goodsList的长度为："+jsonArray.length());
			response.getWriter().append(jsonArray.toString());
		}else if("getIndexGoodsList".equals(remark)) {
			GoodsDao goodsDao=new GoodsDao();
			List<GoodsBean> goodsList = null;
			try {
				goodsList = goodsDao.getIndexGoods();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JSONArray jsonArray=new JSONArray();
			for(int i=0;i<goodsList.size();i++) {
				JSONObject object=new JSONObject();
				object.put("goodsId",goodsList.get(i).getGoods_id());
				object.put("goodsName",goodsList.get(i).getGoods_name());
				System.out.println(goodsList.get(i).getGoods_name());
				object.put("goodsImg",goodsList.get(i).getGoods_img());
//				object.put("goodsPrice",goodsList.get(i).getGoods_price());
				object.put("goodsLink",goodsList.get(i).getGoods_link());
				jsonArray.put(object);
			}
			System.out.println("GoodsServlet:indexGoodsList的长度为："+jsonArray.length());
			response.getWriter().append(jsonArray.toString());
		}
	}
	
//	//获取商品
//	private JSONArray getIndexGoodsList() {
//		// TODO Auto-generated method stub
//		GoodsDao goodsDao=new GoodsDao();
//		List<GoodsBean> goodsList=goodsDao.getIndexGoods();
//		JSONArray jsonArray=new JSONArray();
//		for(int i=0;i<goodsList.size();i++) {
//			JSONObject object=new JSONObject();
//			object.put("goodsId",goodsList.get(i).getGoods_id());
//			object.put("goodsName",goodsList.get(i).getGoods_name());
//			System.out.println(goodsList.get(i).getGoods_name());
//			object.put("goodsImg",goodsList.get(i).getGoods_img());
////			object.put("goodsPrice",goodsList.get(i).getGoods_price());
//			object.put("goodsLink",goodsList.get(i).getGoods_link());
//			jsonArray.put(object);
//		}
//		return jsonArray;
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}
