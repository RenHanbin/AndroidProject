package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.CommentBean;
import dao.CommentDao;

/**
 * Servlet implementation class CommentServlet
 */
@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String remark=request.getParameter("remark");
		System.out.println("CommentServlet:remark="+remark);
		
		if("selectCommList".equals(remark)) {//根据answer_id找到评论列表
			int answerId=Integer.parseInt(request.getParameter("answerId"));
			System.out.println("answerId:"+answerId);
			try {
				selectCommList(answerId,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("addComm".equals(remark)) {//添加评论,根据answerId
			int answerId=Integer.parseInt(request.getParameter("answerId"));
			int userId=Integer.parseInt(request.getParameter("userId"));
			String content=request.getParameter("commContent");
			try {
				addComment(userId,answerId,content,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("selectComm".equals(remark)) {//查询一条评论,根据answerId
			int answerId=Integer.parseInt(request.getParameter("answerId"));
			int userId=Integer.parseInt(request.getParameter("userId"));
			String content=request.getParameter("commContent");
			try {
				selectComment(userId,answerId,content,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("selectCommListByArticleId".equals(remark)) {//根据article_id找到评论列表
			int articleId=Integer.parseInt(request.getParameter("articleId"));
			System.out.println("articleId:"+articleId);
			try {
				selectCommListByArticleId(articleId,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("addCommByArticleId".equals(remark)) {//添加评论,根据articleId
			int articleId=Integer.parseInt(request.getParameter("articleId"));
			int userId=Integer.parseInt(request.getParameter("userId"));
			String content=request.getParameter("commContent");
			try {
				addCommByArticleId(userId,articleId,content,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("selectCommByArticleId".equals(remark)) {//查询一条评论,根据articleId
			int articleId=Integer.parseInt(request.getParameter("articleId"));
			int userId=Integer.parseInt(request.getParameter("userId"));
			String content=request.getParameter("commContent");
			try {
				selectCommByArticleId(userId,articleId,content,request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//查询一条评论,根据articleId
	private void selectCommByArticleId(int userId, int articleId, String content, HttpServletRequest request,
			HttpServletResponse response) throws SQLException {
		CommentDao commentDao=new CommentDao();
		CommentBean comment=commentDao.getCommByUserIdAndArticleId(userId, articleId, content);
		try {
			JSONObject object=new JSONObject();
			object.put("commComtent", comment.getCommentContent());
			 object.put("commTime", comment.getCommentTime());
			 object.put("commUserName",comment.getUserName());
			 object.put("commUserImg",comment.getUserImg());
			 System.out.println(object.toString());
			 response.getWriter().append(object.toString());
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	//查询一条评论,根据answerId
	private void selectComment(int userId, int answerId, String content, HttpServletRequest request,
			HttpServletResponse response) throws SQLException {
		CommentDao commentDao=new CommentDao();
		CommentBean comment=commentDao.getCommByUserIdAndAnswerId(userId, answerId, content);
		try {
			JSONObject object=new JSONObject();
			object.put("commComtent", comment.getCommentContent());
			 object.put("commTime", comment.getCommentTime());
			 object.put("commUserName",comment.getUserName());
			 object.put("commUserImg",comment.getUserImg());
			 System.out.println(object.toString());
			 response.getWriter().append(object.toString());
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	//添加评论
	private void addComment(int userId, int answerId, String content, HttpServletRequest request,
			HttpServletResponse response) throws IOException, SQLException {
		CommentDao commentDao=new CommentDao();
		boolean b=commentDao.addComm(userId, answerId, content);
		JSONObject object=new JSONObject();
		if(b) {
			//发布成功
			System.out.println("发布成功");
			object.put("success", "发布成功");
		}else {
			//发布失败
			System.out.println("发布失败");
			object.put("false", "发布失败");
		}
		response.getWriter().append(object.toString());
	}
	
	//添加评论
	private void addCommByArticleId(int userId, int articleId, String content, HttpServletRequest request,
			HttpServletResponse response) throws IOException, SQLException {
		CommentDao commentDao=new CommentDao();
		boolean b=commentDao.addCommByArticleId(userId, articleId, content);
		JSONObject object=new JSONObject();
		if(b) {
			//发布成功
			System.out.println("发布成功");
			object.put("success", "发布成功");
		}else {
			//发布失败
			System.out.println("发布失败");
			object.put("false", "发布失败");
		}
		response.getWriter().append(object.toString());
	}


	
	//根据answer_id找到评论列表
	private void selectCommList(int answerId, HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
		 CommentDao commentDao=new CommentDao();
		 List<CommentBean> commList=commentDao.findCommListByAnswerId(answerId);
		 JSONArray jsonArray=new JSONArray();
		 for(int i=0;i<commList.size();i++) {
			 JSONObject object=new JSONObject();
			 object.put("commComtent", commList.get(i).getCommentContent());
			 object.put("commTime", commList.get(i).getCommentTime());
			 object.put("commUserName",commList.get(i).getUserName());
			 object.put("commUserImg", commList.get(i).getUserImg());
			 jsonArray.put(object);
		 }
		 response.getWriter().append(jsonArray.toString());
	}
	//根据article_id找到评论列表
	private void selectCommListByArticleId(int articleId, HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
		 CommentDao commentDao=new CommentDao();
		 List<CommentBean> commList=commentDao.findCommListByArticleId(articleId);
		 JSONArray jsonArray=new JSONArray();
		 for(int i=0;i<commList.size();i++) {
			 JSONObject object=new JSONObject();
			 object.put("commComtent", commList.get(i).getCommentContent());
			 object.put("commTime", commList.get(i).getCommentTime());
			 object.put("commUserName",commList.get(i).getUserName());
			 object.put("commUserImg", commList.get(i).getUserImg());
			 jsonArray.put(object);
		 }
		 response.getWriter().append(jsonArray.toString());
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
