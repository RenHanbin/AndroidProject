package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.Article;
import bean.MajorBean;
import bean.UserBean;
import bean.Writer;
import servlet.DataBase;

public class ArticleDao {

	// 获得所有“高考新资讯”
	public List<Article> getAllNews() throws SQLException {
		List<Article> newsList = new ArrayList();
		Connection conn = null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre = null;
			ResultSet res = null;
			String sql = "select article_id,article_title,article_content,article_time,article_img,writer_id from article where article_type=1";
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			while (res.next()) {
				System.out.print("ArticleDao:已经联合查询出高考新资讯");
				Article article = new Article();
				article.setArticleId(res.getInt("article_id"));
				article.setArticleTitle(res.getString("article_title"));
				article.setArticleContent(res.getString("article_content"));
				article.setArticleTime(res.getString("article_time"));
				article.setArticleImg(res.getString("article_img"));
				int writerId = res.getInt("writer_id");
				WriterDao writerDao = new WriterDao();
				article.setWriter(writerDao.getWriterById(writerId));
				newsList.add(article);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ArticleDao:查询出的newslist长度为" + newsList.size());
		conn.close();
		return newsList;
	}

	// 获得所有“经验分享区”
	public List<Article> getAllExperience() throws SQLException {
		List<Article> talkList = new ArrayList();
		Connection conn = null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre = null;
			ResultSet res = null;
			String sql = "select article_id,article_title,article_content,article_img,article_time,user_id from article where article_type=2";
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			while (res.next()) {
				System.out.print("ArticleDao:已经联合查询出talkList");
				Article article2 = new Article();
				article2.setArticleId(res.getInt("article_id"));
				article2.setArticleTitle(res.getString("article_title"));
				article2.setArticleContent(res.getString("article_content"));
				article2.setArticleTime(res.getString("article_time"));
				article2.setArticleImg(res.getString("article_img"));
				int userId = res.getInt("user_id");
				UserDao userDao=new UserDao();
				UserBean user =userDao.getUserByUserId(userId);
				article2.setUser(user);
				talkList.add(article2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ArticleDao:查询出的经验分享区长度为" + talkList.size());
		conn.close();
		return talkList;
	}

	// 获得首页“高考新资讯”内容
	public List<Article> getIndexNews() throws SQLException {
		List<Article> newsList = new ArrayList();
		Connection conn = null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre = null;
			ResultSet res = null;
			String sql = "select article_id,article_title,article_content,article_time,article_img,writer_id from article where article_type=1 limit 0,3";
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			while (res.next()) {
				System.out.print("ArticleDao:已经联合查询出高考新资讯");
				Article article = new Article();
				article.setArticleId(res.getInt("article_id"));
				article.setArticleTitle(res.getString("article_title"));
				article.setArticleContent(res.getString("article_content"));
				article.setArticleTime(res.getString("article_time"));
				article.setArticleImg(res.getString("article_img"));
				int writerId = res.getInt("article_id");
				WriterDao writerDao = new WriterDao();
				article.setWriter(writerDao.getWriterById(writerId));
				newsList.add(article);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ArticleDao:查询出的indexNewslist长度为" + newsList.size());
		conn.close();
		return newsList;
	}

	// 获得首页“经验分享区”内容
	public List<Article> getIndexExperience() throws SQLException {
		List<Article> talkList = new ArrayList();
		Connection conn = null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre = null;
			ResultSet res = null;
			String sql = "select article_id,article_title,article_content,article_img,article_time,user_id from article where article_type=2 limit 0,1";
			pre = conn.prepareStatement(sql);
			res = pre.executeQuery();
			while (res.next()) {
				System.out.print("ArticleDao:已经联合查询出indextalkList");
				Article article2 = new Article();
				article2.setArticleId(res.getInt("article_id"));
				article2.setArticleTitle(res.getString("article_title"));
				article2.setArticleContent(res.getString("article_content"));
				article2.setArticleTime(res.getString("article_time"));
				article2.setArticleImg(res.getString("article_img"));
				int userId = res.getInt("user_id");
				UserDao userDao=new UserDao();
				UserBean user =userDao.getUserByUserId(userId);
				article2.setUser(user);
				talkList.add(article2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("ArticleDao:查询出的首页的经验分享区的长度为" + talkList.size());
		conn.close();
		return talkList;
	}

	// 3级页面：获取高考新资讯文章内容
	public Article getArticleById(int articleId) throws SQLException {
		Article article = new Article();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from article where article_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, articleId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				article.setArticleId(rs.getInt(1));
				article.setArticleTitle(rs.getString(2));
				article.setArticleContent(rs.getString(3));
				article.setArticleTime(rs.getString(4));
				article.setArticleImg(rs.getString(5));
				Writer writer = new WriterDao().getWriterById(rs.getInt(6));
				article.setWriter(writer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return article;
	}
	
	//3级页面：获取经验分享区文章内容
	public Article getExperienceArticleById(int articleId) throws SQLException {
		Article article = new Article();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from article where article_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, articleId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				article.setArticleId(rs.getInt(1));
				article.setArticleTitle(rs.getString(2));
				article.setArticleContent(rs.getString(3));
				article.setArticleTime(rs.getString(4));
				article.setArticleImg(rs.getString(5));
				UserBean user = new UserDao().getUserByUserId(rs.getInt("user_id"));
				article.setUser(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return article;
	}
	
	//我的：根据userId获得该用户所有的文章
	public List<Article> getAllArticleById(int userId) throws SQLException{
		List<Article> articleList=new ArrayList<Article>();
			
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from article where user_id=? and article_type=2";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Article article = new Article();
				article.setArticleId(rs.getInt("article_id"));
				article.setArticleTitle(rs.getString("article_title"));
				article.setArticleContent(rs.getString("article_content"));
				article.setArticleTime(rs.getString("article_time"));
				article.setArticleImg(rs.getString("article_img"));
				UserDao userDao=new UserDao();
				UserBean user =userDao.getUserByUserId(userId);
				article.setUser(user);
				articleList.add(article);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		return articleList;
	}

	//添加文章
	public boolean addArticle(int userId,String articleName,String articleContent) throws SQLException {
		int i=0;
		Connection conn=null;
		try {
			conn=DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="insert into article(user_id,article_time,article_type,article_title,article_content) values (?,?,2,?,?) ";
			pre=conn.prepareStatement(sql);
			pre.setInt(1, userId);
			Date day=new Date();    
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			String time=df.format(day);
			System.out.println(time); 
			pre.setString(2, time);
			pre.setString(3, articleName);
			pre.setString(4, articleContent);
			i=pre.executeUpdate();
			if(i>0) {
				conn.close();
				return true;
			}else {
				conn.close();
				return false;
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return false;
	}
	
	
}
