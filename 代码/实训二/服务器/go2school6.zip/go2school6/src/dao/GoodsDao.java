package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Article;
import bean.GoodsBean;
import servlet.DataBase;

public class GoodsDao {
	//获取所有商品
	public List<GoodsBean> getAllGoods() throws SQLException{
		List<GoodsBean> goodsList=new ArrayList<GoodsBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select goods_id, goods_name, goods_img, goods_link from goods ";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			while(res.next()) {
				System.out.print("ArticleDao:已经联合查询出talkList");
				GoodsBean goods=new GoodsBean();
				goods.setGoods_id(res.getInt("goods_id"));
				goods.setGoods_name(res.getString("goods_name"));
				goods.setGoods_img(res.getString("goods_img"));
//				goods.setGoods_price(res.getDouble("goods_price"));
				goods.setGoods_link(res.getString("goods_link"));
//				int writerId=res.getInt("writer_id");
//				WriterDao writerDao=new WriterDao();
//				article2.setWriter(writerDao.getWriterById(writerId));
				goodsList.add(goods);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("GoodsBean:查询出的goodslist长度为"+goodsList.size());
		conn.close();
		return goodsList;
	}

	//获取首页资料内容
	public List<GoodsBean> getIndexGoods() throws SQLException {
		List<GoodsBean> goodsList=new ArrayList();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select goods_id,goods_name,goods_img,goods_link from goods ";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			while(res.next()) {
				System.out.print("GoodsDao:已经联合查询出indextalkList");
				GoodsBean goods=new GoodsBean();
				goods.setGoods_id(res.getInt("goods_id"));
				goods.setGoods_name(res.getString("goods_name"));
				goods.setGoods_img(res.getString("goods_img"));
//				goods.setGoods_price(res.getDouble("goods_price"));
				goods.setGoods_link(res.getString("goods_link"));
//				int writerId=res.getInt("writer_id");
//				WriterDao writerDao=new WriterDao();
//				article2.setWriter(writerDao.getWriterById(writerId));
				goodsList.add(goods);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("GoodsDao:查询出的indextalklist长度为"+goodsList.size());
		conn.close();
		return goodsList;
	}
	

}
