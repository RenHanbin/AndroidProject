package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.MajorBean;
import bean.MajorTypeBean;
import bean.UserBean;
import bean.Work;
import servlet.DataBase;

public class MajorDao {
	
	/**
	 * 获得专业列表
	 * @return
	 * @throws SQLException 
	 */
	
	public List<MajorBean> getMajorList() throws SQLException{
		List<MajorBean> majorList=new ArrayList<MajorBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select * "
					+ "from major,major_type "
					+ "where major.major_type_id=major_type.major_type_id "
					+ "order by major.major_want DESC";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			while(res.next()) {
				System.out.print("MajorDao:已经联合查询出专业");
				MajorBean major=new MajorBean();
				major.setMajorId(res.getInt("major_id"));
				major.setMajorName(res.getString("major_name"));
				major.setMajorWorkPercent(res.getDouble("major_workPercent"));
				major.setMajorSalary(res.getInt("major_salary"));
				major.setMajorTypeId(res.getInt("major_type_id"));
				major.setMajorNeed(res.getInt("major_need"));
				major.setMajorWant(res.getInt("major_want"));
				major.setMajorTypeName(res.getString("major_type_name"));
				major.setMajorIntroduce(res.getString("major_introduce"));
				major.setMajorSubject(res.getString("major_subject"));
				major.setMajorWork(res.getString("major_work"));
				majorList.add(major);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return majorList;
	}

	/**
	 * 专业
	 * @throws SQLException 
	 */
	public List<MajorBean> getMajorListByTypeName(String typeName) throws SQLException{
		List<MajorBean> majorList=new ArrayList<MajorBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select * "
					+ "from major,major_type "
					+ "where major.major_type_id=major_type.major_type_id and major_type_name=\""+typeName+"\" ";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			System.out.print("MajorDao:已经联合查询出专业");
			while(res.next()) {				
				MajorBean major=new MajorBean();
				major.setMajorId(res.getInt("major_id"));
				major.setMajorName(res.getString("major_name"));
				major.setMajorWorkPercent(res.getDouble("major_workPercent"));
				major.setMajorSalary(res.getInt("major_salary"));
				major.setMajorTypeId(res.getInt("major_type_id"));
				major.setMajorTypeName(res.getString("major_type_name"));
				major.setMajorIntroduce(res.getString("major_introduce"));
				major.setMajorSubject(res.getString("major_subject"));
				major.setMajorWork(res.getString("major_work"));
				majorList.add(major);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return majorList;
	}
	
	/**
	 * 专业类别
	 * @throws SQLException 
	 */
	public List<MajorTypeBean> getMajorTypeList() throws SQLException{
		List<MajorTypeBean> typeList=new ArrayList<MajorTypeBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select * "
					+ "from major_type ";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			System.out.print("MajorDao:已经联合查询出专业类别");
			while(res.next()) {
				
				MajorTypeBean type = new MajorTypeBean();
				type.setMajorTypeId(res.getInt("major_type_id"));
				type.setMajorTypeName(res.getString("major_type_name"));
				typeList.add(type);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return typeList;
	}
	
	
	/**
	 * 根据课程选择专业类别
	 * @throws SQLException 
	 */
	public List<MajorTypeBean> getMajorTypeListById(int typeId) throws SQLException{
		List<MajorTypeBean> typeList=new ArrayList<MajorTypeBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select * "
					+ "from major_type "
					+ "where major_type_id=\""+typeId+"\" ";
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			System.out.print("MajorDao:已经联合查询出专业类别");
			while(res.next()) {
				
				MajorTypeBean type = new MajorTypeBean();
				type.setMajorTypeId(typeId);
				type.setMajorTypeName(res.getString("major_type_name"));
				typeList.add(type);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return typeList;
	}
	
	/**
	 * 考研率
	 * @return
	 * @throws SQLException 
	 */
	public List<MajorBean> getMajorLearnList() throws SQLException{
		List<MajorBean> majorLearnList=new ArrayList<MajorBean>();
		Connection conn= null;
		PreparedStatement pre=null;
		ResultSet res=null;
		String sql="select * "
				+ "from major,major_type "
				+ "where major.major_type_id=major_type.major_type_id "
				+ "order by major_study DESC";
		try {	
			conn= DataBase.getConnection();
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			System.out.print("MajorDao:已经联合查询出专业");
			while(res.next()) {
				MajorBean major=new MajorBean();
				major.setMajorId(res.getInt("major_id"));
				major.setMajorName(res.getString("major_name"));
				major.setMajorTypeName(res.getString("major_type_name"));
				major.setMajorWorkPercent(res.getDouble("major_workPercent"));
				major.setMajorStudy(res.getDouble("major_study"));
				major.setMajorGo(res.getDouble("major_go"));
				major.setMajorIntroduce(res.getString("major_introduce"));
				major.setMajorSubject(res.getString("major_subject"));
				major.setMajorWork(res.getString("major_work"));
				majorLearnList.add(major);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return majorLearnList;
		
	}

	/**
	 * 出国
	 * @throws SQLException 
	 */
	public List<MajorBean> getMajorOutList() throws SQLException{
		List<MajorBean> majorLearnList=new ArrayList<MajorBean>();
		Connection conn= null;
		PreparedStatement pre=null;
		ResultSet res=null;
		String sql="select * "
				+ "from major,major_type "
				+ "where major.major_type_id=major_type.major_type_id "
				+ "order by major_go DESC";
		try {	
			conn= DataBase.getConnection();
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			while(res.next()) {
				System.out.print("MajorDao:已经联合查询出专业");
				MajorBean major=new MajorBean();
				major.setMajorId(res.getInt("major_id"));
				major.setMajorName(res.getString("major_name"));
				major.setMajorTypeName(res.getString("major_type_name"));
				major.setMajorWorkPercent(res.getDouble("major_workPercent"));
				major.setMajorStudy(res.getDouble("major_study"));
				major.setMajorGo(res.getDouble("major_go"));
				major.setMajorIntroduce(res.getString("major_introduce"));
				major.setMajorSubject(res.getString("major_subject"));
				major.setMajorWork(res.getString("major_work"));
				majorLearnList.add(major);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return majorLearnList;
		
	}
	
	/**
	 * 就业
	 * @throws SQLException 
	 */
	public List<MajorBean> getMajorWorkList() throws SQLException{
		List<MajorBean> majorLearnList=new ArrayList<MajorBean>();
		Connection conn= null;
		PreparedStatement pre=null;
		ResultSet res=null;
		String sql="select * "
				+ "from major,major_type "
				+ "where major.major_type_id=major_type.major_type_id "
				+ "order by major_workPercent DESC";
		try {	
			conn= DataBase.getConnection();
			pre=conn.prepareStatement(sql);
			res=pre.executeQuery();
			while(res.next()) {
				System.out.print("MajorDao:已经联合查询出专业");
				MajorBean major=new MajorBean();
				major.setMajorId(res.getInt("major_id"));
				major.setMajorName(res.getString("major_name"));
				major.setMajorTypeName(res.getString("major_type_name"));
				major.setMajorWorkPercent(res.getDouble("major_workPercent"));
				major.setMajorSalary(res.getInt("major_salary"));
				major.setMajorStudy(res.getDouble("major_study"));
				major.setMajorGo(res.getDouble("major_go"));
				major.setMajorIntroduce(res.getString("major_introduce"));
				major.setMajorSubject(res.getString("major_subject"));
				major.setMajorWork(res.getString("major_work"));
				majorLearnList.add(major);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return majorLearnList;
		
	}
}
