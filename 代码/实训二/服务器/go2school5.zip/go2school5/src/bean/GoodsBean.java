package bean;

public class GoodsBean {
	private int goods_id;
	private String goods_name;
	private String goods_img;
	private double goods_price;
	private String goods_link;
	
	
	public GoodsBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + goods_id;
		result = prime * result + ((goods_img == null) ? 0 : goods_img.hashCode());
		result = prime * result + ((goods_link == null) ? 0 : goods_link.hashCode());
		result = prime * result + ((goods_name == null) ? 0 : goods_name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(goods_price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GoodsBean other = (GoodsBean) obj;
		if (goods_id != other.goods_id)
			return false;
		if (goods_img == null) {
			if (other.goods_img != null)
				return false;
		} else if (!goods_img.equals(other.goods_img))
			return false;
		if (goods_link == null) {
			if (other.goods_link != null)
				return false;
		} else if (!goods_link.equals(other.goods_link))
			return false;
		if (goods_name == null) {
			if (other.goods_name != null)
				return false;
		} else if (!goods_name.equals(other.goods_name))
			return false;
		if (Double.doubleToLongBits(goods_price) != Double.doubleToLongBits(other.goods_price))
			return false;
		return true;
	}
	public GoodsBean(int goods_id, String goods_name, String goods_img, double goods_price, String goods_link) {
		super();
		this.goods_id = goods_id;
		this.goods_name = goods_name;
		this.goods_img = goods_img;
		this.goods_price = goods_price;
		this.goods_link = goods_link;
	}
	@Override
	public String toString() {
		return "GoodsBean [goods_id=" + goods_id + ", goods_name=" + goods_name + ", goods_img=" + goods_img
				+ ", goods_price=" + goods_price + ", goods_link=" + goods_link + "]";
	}
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public String getGoods_img() {
		return goods_img;
	}
	public void setGoods_img(String goods_img) {
		this.goods_img = goods_img;
	}
	public double getGoods_price() {
		return goods_price;
	}
	public void setGoods_price(double goods_price) {
		this.goods_price = goods_price;
	}
	public String getGoods_link() {
		return goods_link;
	}
	public void setGoods_link(String goods_link) {
		this.goods_link = goods_link;
	}
	

}
