package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.CommentBean;
import servlet.DataBase;

public class CommentDao {
	//根据answer_id找到评论列表
	public List<CommentBean> findCommListByAnswerId(int answerId){
		List<CommentBean> commList=new ArrayList<CommentBean>();
		Connection conn=null;
		try {
			conn = DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="select user_name,user_img,comment_content,comment_time from comment,user where answer_id=? and user.user_id=comment.user_id";
			pre=conn.prepareStatement(sql);
			pre.setInt(1, answerId);
			res=pre.executeQuery();
			while(res.next()) {
				CommentBean comment=new CommentBean();
				comment.setCommentContent(res.getString("comment_content"));
				comment.setCommentTime(res.getDate("comment_time"));
				System.out.println("评论时间："+res.getDate("comment_time").toString());
				comment.setUserName(res.getString("user_name"));
				comment.setUserImg(res.getString("user_img"));
				commList.add(comment);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("commList:"+commList);
		return commList;
		
	}
	//根据article_id找到评论列表
		public List<CommentBean> findCommListByArticleId(int articleId){
			List<CommentBean> commList=new ArrayList<CommentBean>();
			Connection conn=null;
			try {
				conn = DataBase.getConnection();
				PreparedStatement pre=null;
				ResultSet res=null;
				String sql="select user_name,user_img,comment_content,comment_time from comment,user where article_id=? and user.user_id=comment.user_id";
				pre=conn.prepareStatement(sql);
				pre.setInt(1, articleId);
				res=pre.executeQuery();
				while(res.next()) {
					CommentBean comment=new CommentBean();
					comment.setCommentContent(res.getString("comment_content"));
					comment.setCommentTime(res.getDate("comment_time"));
					System.out.println("评论时间："+res.getDate("comment_time").toString());
					comment.setUserName(res.getString("user_name"));
					comment.setUserImg(res.getString("user_img"));
					commList.add(comment);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("commList:"+commList);
			return commList;
			
		}
	//添加评论，根据answerId
	public boolean addComm(int userId,int answerId,String content) {
		int i=0;
		Connection conn=null;
		try {
			conn=DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="insert into comment(user_id,comment_content,answer_id,comment_time) values (?,?,?,?) ";
			pre=conn.prepareStatement(sql);
			pre.setInt(1, userId);
			pre.setString(2, content);
			pre.setInt(3, answerId);
			Date day=new Date();    
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			String time=df.format(day);
			System.out.println(time); 
			pre.setString(4, time);
			i=pre.executeUpdate();
			if(i>0) {
				return true;
			}else {
				return false;
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	//添加评论，根据articleId
	public boolean addCommByArticleId(int userId,int articleId,String content) {
		int i=0;
		Connection conn=null;
		try {
			conn=DataBase.getConnection();
			PreparedStatement pre=null;
			ResultSet res=null;
			String sql="insert into comment(user_id,comment_content,article_id,comment_time) values (?,?,?,?) ";
			pre=conn.prepareStatement(sql);
			pre.setInt(1, userId);
			pre.setString(2, content);
			pre.setInt(3, articleId);
			Date day=new Date();    
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			String time=df.format(day);
			System.out.println(time); 
			pre.setString(4, time);
			i=pre.executeUpdate();
			if(i>0) {
				return true;
			}else {
				return false;
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	//根据userId和answerId和评论内容找到评论
	public CommentBean getCommByUserIdAndAnswerId(int userId,int answerId,String content) {
		CommentBean comment=new CommentBean();
		Connection conn = null;
		try {
			conn=DataBase.getConnection();
			PreparedStatement pstmt = null;
			ResultSet res = null;
			String sql = "select user_name,user_img,comment_content,comment_time from comment,user where answer_id=? and comment.user_id=? and comment_content=? and user.user_id=comment.user_id";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, answerId);
			pstmt.setInt(2, userId);
			pstmt.setString(3, content);
			res = pstmt.executeQuery();
			while(res.next()) {
				comment.setCommentContent(res.getString("comment_content"));
				comment.setCommentTime(res.getDate("comment_time"));
				System.out.println("评论时间："+res.getDate("comment_time").toString());
				comment.setUserName(res.getString("user_name"));
				comment.setUserImg(res.getString("user_img"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return comment;
	}
	
	//根据userId和articleId和评论内容找到评论
	public CommentBean getCommByUserIdAndArticleId(int userId,int articleId,String content) {
		CommentBean comment=new CommentBean();
		Connection conn = null;
		try {
			conn=DataBase.getConnection();
			PreparedStatement pstmt = null;
			ResultSet res = null;
			String sql = "select user_name,user_img,comment_content,comment_time from comment,user where article_id=? and comment.user_id=? and comment_content=? and user.user_id=comment.user_id";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, articleId);
			pstmt.setInt(2, userId);
			pstmt.setString(3, content);
			res = pstmt.executeQuery();
			while(res.next()) {
				comment.setCommentContent(res.getString("comment_content"));
				comment.setCommentTime(res.getDate("comment_time"));
				System.out.println("评论时间："+res.getDate("comment_time").toString());
				comment.setUserName(res.getString("user_name"));
				comment.setUserImg(res.getString("user_img"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return comment;
	}


}
