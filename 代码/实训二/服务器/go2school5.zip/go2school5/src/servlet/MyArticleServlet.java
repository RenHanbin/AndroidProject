package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.Article;
import dao.ArticleDao;
import dao.MyQuestDao;

/**
 * Servlet implementation class MyArticle
 */
@WebServlet("/MyArticle")
public class MyArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String remark=request.getParameter("remark");
		int userId=Integer.parseInt(request.getParameter("userId"));
		if("getAllArticle".equals(remark)) {
			//点击我的首页中文章，获得该用户写过的所有文章
			System.out.println("我的：查找所有写过的文章");
			ArticleDao articleDao=new ArticleDao();
			try {
				List<Article> articleList=articleDao.getAllArticleById(userId);
				JSONArray jsonArray=new JSONArray();
				for(int i=0;i<articleList.size();i++) {
					JSONObject object=new JSONObject();
					object.put("articleId",articleList.get(i).getArticleId());
					object.put("articleTitle",articleList.get(i).getArticleTitle());
					object.put("articleContent",articleList.get(i).getArticleContent());
					object.put("articleImg",articleList.get(i).getArticleImg());
					object.put("articleTime",articleList.get(i).getArticleTime());
					object.put("articleUser",articleList.get(i).getUser());
					jsonArray.put(object);
				}
				System.out.println("myArticle:"+jsonArray.toString());
				response.getWriter().append(jsonArray.toString());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if("addArticle".equals(remark)) {
			//添加文章
			String articleName=request.getParameter("title");
			String articleContent=request.getParameter("content");
			ArticleDao articleDao=new ArticleDao();
			boolean b=articleDao.addArticle(userId, articleName, articleContent);
			JSONObject object=new JSONObject();
			if(b) {
				//发布成功
				System.out.println("发布成功");
				object.put("success", "发布成功");
			}else {
				//发布失败
				System.out.println("发布失败");
				object.put("false", "发布失败");
			}
			response.getWriter().append(object.toString());
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
