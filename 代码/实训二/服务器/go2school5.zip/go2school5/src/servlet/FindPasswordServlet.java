package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import dao.UserDao;

/**
 * Servlet implementation class FindPasswordServlet
 */
@WebServlet("/FindPasswordServlet")
public class FindPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String userTel=request.getParameter("userTel");
		System.out.println(userTel);
		UserDao userDao=new UserDao();
		int userId=userDao.findUserIdByUserTel(userTel);
		JSONObject object=new JSONObject();
		object.put("userId", userId);
		response.getWriter().append(object.toString());
		//remark=findUserId newPwd

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String remark=request.getParameter("remark");
		System.out.println("FindPasswordServlet:remark="+remark);
		if("findUserId".equals(remark)) {
			//通过手机号找用户Id
			findUserId(request,response);	
		}else if("newPwd".equals(remark)) {
			//修改密码
			newPwd(request,response);
		}
	}
	protected void findUserId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String userTel=request.getParameter("userTel");
		System.out.println(userTel);
		UserDao userDao=new UserDao();
		int userId=userDao.findUserIdByUserTel(userTel);
		System.out.println("userId="+userId);
		JSONObject object=new JSONObject();
		object.put("userId", userId);
		System.out.println("userId="+userId);
		response.getWriter().append(object.toString());
	}
	protected void newPwd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		int userId=Integer.parseInt(request.getParameter("userId"));
		String userNewPwd=request.getParameter("userNewPwd");
		
		System.out.println("8888888888"+"userId:"+userId+",userNewPwd:"+userNewPwd);
		UserDao userDao=new UserDao();
		boolean b=userDao.updateUserPasswordByUserId(userId,userNewPwd);
		JSONObject object=new JSONObject();
		if(b) {
			//修改成功
			object.put("success", "修改密码成功");
		}else {
			//修改失败
			object.put("false", "修改密码失败");
		}
		response.getWriter().append(object.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
