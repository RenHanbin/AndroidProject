package com.example.celia.demo1.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.example.celia.demo1.R;
import com.example.celia.demo1.bean.Article;

import java.util.ArrayList;
import java.util.List;

public class MyArticleAdapter extends BaseAdapter {
    private Context context;
    private int itemLayoutID;
    private List<Article> experList = new ArrayList<Article>();

    public MyArticleAdapter(Context context, List<Article> articles, int itemLayoutID){
        this.context=context;
        experList=articles;
        this.itemLayoutID=itemLayoutID;
    }
    @Override
    public int getCount() {
        return experList.size();
    }

    @Override
    public Object getItem(int position) {
        return experList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder vh = null;
        //1. 获取item子布局
        if(null == convertView){
            convertView = LayoutInflater.from(context).inflate(
                    itemLayoutID, null);
            vh = new ViewHolder();
            vh.articleName = convertView.findViewById(R.id.tv_title);
            vh.articleTime = convertView.findViewById(R.id.tv_time);
            //缓存ViewHolder对象
            convertView.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }
        //2. 填充数据
        Article article = experList.get(position);
        vh.articleName.setText(article.getArticleTitle());
        vh.articleTime.setText(article.getArticleTime());

        return convertView;
    }

    class ViewHolder{
        private TextView articleName;
        private TextView articleTime;

    }
}
